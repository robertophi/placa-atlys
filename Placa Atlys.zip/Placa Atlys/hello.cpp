#include <iostream>

int main(void){
	std::cout << "Hello from LEON3!!" << std::endl;
	return 0;
}
